/**
 * Let's take advantage of some JS!
 * 
 * You can run any kind of JS in here that you'd like. Intervals, events, whatever.
 * This is however sandboxed within the launcher, so you cannot make system calls or
 * anything Tauri-related. Even if you could, the backend permissions are heavily locked
 * down and you wouldn't be able to do much anyways. 
 *
 */

// Simple example, change the version number to something random every half-second
setInterval(() => {
  const versionSection = document.getElementById('version')

  let major, minor, patch;

  // Between 1 and 10
  major = Math.floor(Math.random() * 10) + 1;
  minor = Math.floor(Math.random() * 10) + 1;
  patch = Math.floor(Math.random() * 10) + 1;

  versionSection.innerHTML = `v${major}.${minor}.${patch}`;
}, 500);

// You can also watch for events.
//
// Honestly I don't know why I am writing these examples, this *literally* just functions
// just like any other javascript file, there are no special limitations. Do whatever you want.

// Create a big button in the middle of the screen
const button = document.createElement('button');
button.innerHTML = 'Don\'t you dare click me!';
button.style.position = 'absolute';
button.style.top = '50%';
button.style.left = '50%';
button.style.transform = 'translate(-50%, -50%)';
button.style.fontSize = '50px';

document.body.appendChild(button);
let clickedOnce = false

button.addEventListener('click', () => {
  if (!clickedOnce) {
    button.innerHTML = 'Don\'t click me again!'

    clickedOnce = true
  } else {
    button.innerHTML = 'You asked for it.'

    // Fuck up everything
    const divs = document.getElementsByTagName('div')

    for (let i = 0; i < divs.length; i++) {
      const div = divs[i]

      // Spare the main App div
      if (div.className === 'App') continue

      // Set tranform transiton
      div.style.transition = `transform ${Math.random() * 5}s ease-in-out`

      // Spin that shit
      div.style.transform = `rotate(${Math.random() * 360}deg)`
    }
  }
})
